# Example Rule Combinations

## Full-Stack Next.js Project

Combine these rules for a complete Next.js application:

```bash
# In your project root, create .cursorrules
cat nextjs-14.cursorrules > .cursorrules
echo "

" >> .cursorrules
cat react-typescript.cursorrules >> .cursorrules
echo "

" >> .cursorrules
cat testing.cursorrules >> .cursorrules
```

## Node.js API with Testing

```bash
cat node-backend.cursorrules > .cursorrules
echo "

" >> .cursorrules
cat testing.cursorrules >> .cursorrules
echo "

" >> .cursorrules
cat debugging.cursorrules >> .cursorrules
```

## Python Data Science Project

```bash
cat python.cursorrules > .cursorrules
echo "

" >> .cursorrules
cat performance.cursorrules >> .cursorrules
```

## Tips for Combining Rules

1. **No Conflicts**: Our rules are designed to work together
2. **Order Matters**: Put framework-specific rules first
3. **Add Separators**: Use comments to organize sections
4. **Test Incrementally**: Add one rule set at a time

## Custom Project Rules Template

```
# Project: [Your Project Name]
# Team: [Your Team]
# Last Updated: [Date]

# === FRAMEWORK RULES ===
[Paste framework rules here]

# === CODING STANDARDS ===
[Paste testing/debugging rules here]

# === PROJECT SPECIFIC ===
# Add your custom patterns here
- Always use our custom auth hook
- Follow our API naming convention
- Use our shared component library
```
