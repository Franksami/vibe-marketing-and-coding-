# Quick Start Guide

## 🚀 Getting Started in 2 Minutes

1. **Choose Your Framework**
   - Navigate to the `rules` folder
   - Find the rule file for your framework (e.g., `react-typescript.cursorrules`)

2. **Install in Your Project**
   - Copy the chosen `.cursorrules` file to your project root
   - Rename it to `.cursorrules` (remove the framework prefix)

3. **Start Coding with AI**
   - Open your project in Cursor
   - The rules will automatically guide AI code generation
   - Try asking Cursor to create a component or fix a bug!

## 📁 What's Included

- **react-typescript.cursorrules** - React + TypeScript patterns
- **nextjs-14.cursorrules** - Next.js App Router patterns
- **node-backend.cursorrules** - Node.js backend patterns
- **python.cursorrules** - Python best practices
- **testing.cursorrules** - Comprehensive testing patterns
- **debugging.cursorrules** - Systematic debugging approach
- **performance.cursorrules** - Performance optimization

## 💡 Pro Tips

1. **Combine Rules**: You can merge multiple rule files for full-stack projects
2. **Customize**: Add your team's specific patterns and conventions
3. **Share**: Create project-specific rules and share with your team

## 🎯 Next Steps

1. Join our community for advanced rules and updates
2. Check out our 7-day email course for more AI coding tips
3. Explore our premium templates and frameworks

---

**Need Help?** Visit [vibeacademy.com](https://vibeacademy.com) or join our Skool community!
