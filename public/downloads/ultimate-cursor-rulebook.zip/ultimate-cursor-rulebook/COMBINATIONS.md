# Rule Combination Examples

## Full-Stack Next.js + Supabase

```bash
# Combine Next.js, React, and Supabase rules
cat frameworks/nextjs-14-advanced.cursorrules > .cursorrules
echo -e "\n\n# React Patterns\n" >> .cursorrules
cat frameworks/react-pro.cursorrules >> .cursorrules
echo -e "\n\n# Supabase Integration\n" >> .cursorrules
cat bonuses/supabase-integration.cursorrules >> .cursorrules
```

## Enterprise Node.js API

```bash
# Combine Node.js, Testing, Security, and Performance
cat frameworks/nodejs-enterprise.cursorrules > .cursorrules
echo -e "\n\n# Testing Excellence\n" >> .cursorrules
cat task-specific/testing-master.cursorrules >> .cursorrules
echo -e "\n\n# Security First\n" >> .cursorrules
cat task-specific/security-auditor.cursorrules >> .cursorrules
echo -e "\n\n# Performance\n" >> .cursorrules
cat task-specific/performance-optimizer.cursorrules >> .cursorrules
```

## SaaS MVP

```bash
# Fast SaaS development combo
cat bonuses/startup-mvp.cursorrules > .cursorrules
echo -e "\n\n# SaaS Patterns\n" >> .cursorrules
cat industry-specific/saas-application.cursorrules >> .cursorrules
```

## E-commerce Platform

```bash
# E-commerce focused development
cat industry-specific/ecommerce-platform.cursorrules > .cursorrules
echo -e "\n\n# Payment Integration\n" >> .cursorrules
cat task-specific/payment-integration.cursorrules >> .cursorrules
echo -e "\n\n# Performance for Scale\n" >> .cursorrules
cat task-specific/performance-optimizer.cursorrules >> .cursorrules
```

## Tips for Combining Rules

1. **Order Matters**: Put general rules first, specific rules last
2. **Avoid Conflicts**: Review combined rules for contradictions
3. **Test Incrementally**: Add one ruleset at a time
4. **Document Changes**: Add comments for your customizations
5. **Share with Team**: Create a shared repository of combinations

## Creating Your Own Combinations

1. Start with a base framework rule
2. Add task-specific rules for your workflow
3. Include industry rules if applicable
4. Top off with productivity boosters
5. Test and refine

Remember: The best ruleset is the one that matches YOUR workflow!
